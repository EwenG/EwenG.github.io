# clj-data.el

clj-data.el is an emacs library that provides:

- Utilities to manipulate elisp data in an immutable, Clojure-like way
- Printing of elisp data to a Clojure-like data format
- Pretty printing of elisp data to a Clojure-like data format
- Utilities to browse Clojure-like data