# Logback reloading

Use the `replique/logback-reload` command or the `replique.interactive/logback-reload` function to reload a logback configuration.
The `replique.interactive/logback-reload` takes the url of the logback configuration to reload as parameter.

# Log4j2 reloading

Use the `replique/log4j2-reload` command or the `replique.interactive/log4j2-reload` function to reload a log4j2 configuration.
The `replique.interactive/log4j2-reload` takes the url of the log4j2 configuration to reload as parameter.