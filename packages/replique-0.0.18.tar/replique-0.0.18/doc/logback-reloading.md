# Logback reloading

Use the `replique/logback-reload` command or the `replique.interactive/logback-reload` function to reload a logback configuration.
The `replique.interactive/logback-reload` takes the url of the logback configuration to reload as parameter.